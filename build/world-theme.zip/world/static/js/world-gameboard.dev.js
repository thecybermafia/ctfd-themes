// Ensure CTFd._internal.challenge always has preRender/postRender guards
(function() {
  if (typeof window !== "undefined") {
    if (!window.CTFd) window.CTFd = {};
    if (!window.CTFd._internal) window.CTFd._internal = {};
    let _chal = window.CTFd._internal.challenge || {};
    if (!_chal.preRender) _chal.preRender = function() {};
    if (!_chal.postRender) _chal.postRender = function() {};
    try {
      Object.defineProperty(window.CTFd._internal, "challenge", {
        get() {
          if (!_chal.preRender) _chal.preRender = function() {};
          if (!_chal.postRender) _chal.postRender = function() {};
          return _chal;
        },
        set(val) {
          _chal = val || {};
          if (!_chal.preRender) _chal.preRender = function() {};
          if (!_chal.postRender) _chal.postRender = function() {};
        },
        configurable: true,
        enumerable: true
      });
    } catch (e) {
      console.warn("Could not define CTFd._internal.challenge proxy:", e);
    }
  }
})();

const CALIBRATED_CENTROIDS = {"AE": [627.84, 396.25], "AF": [661.95, 361.91], "AL": [531.47, 338.82], "AM": [600.24, 339.32], "AO": [524.86, 500.51], "AR": [296.09, 552.82], "AT": [515.99, 312.14], "AU": [845.86, 530.31], "AZ": [607.53, 340.31], "BA": [525.54, 325.69], "BD": [727.58, 394.34], "BE": [488.28, 298.9], "BF": [472.37, 427.35], "BG": [545.42, 331.78], "BI": [559.0, 473.02], "BJ": [481.99, 433.88], "BN": [797.73, 450.24], "BO": [293.81, 510.55], "BR": [337.78, 496.81], "BS": [256.46, 392.38], "BT": [727.73, 383.56], "BW": [543.21, 526.18], "BY": [554.57, 286.24], "BZ": [226.57, 414.14], "CA": [157.99, 255.21], "CD": [540.69, 468.15], "CF": [535.7, 444.07], "CG": [519.68, 463.16], "CH": [496.43, 315.63], "CI": [459.5, 442.41], "CL": [270.25, 606.56], "CM": [509.37, 450.52], "CN": [778.45, 365.9], "CO": [269.73, 453.98], "CR": [239.78, 435.18], "CU": [256.84, 402.34], "CY": [568.34, 359.0], "CZ": [515.95, 302.01], "DE": [504.23, 292.94], "DJ": [593.68, 431.0], "DK": [501.22, 271.78], "DO": [276.53, 409.1], "DZ": [482.98, 383.44], "EC": [255.42, 466.73], "EE": [547.7, 259.55], "EG": [557.66, 388.25], "EH": [434.07, 397.99], "ER": [581.67, 417.84], "ES": [464.97, 343.5], "ET": [582.72, 439.1], "FI": [547.99, 237.62], "FJ": [973.81, 513.91], "FK": [311.18, 632.05], "FR": [481.45, 312.58], "GA": [505.87, 465.75], "GB": [470.72, 291.44], "GE": [594.72, 332.88], "GF": [326.61, 451.94], "GH": [471.82, 443.97], "GL": [359.56, 101.2], "GM": [430.4, 425.79], "GN": [447.5, 433.73], "GQ": [504.61, 458.74], "GR": [535.9, 342.94], "GT": [221.5, 421.15], "GW": [432.62, 429.86], "GY": [310.19, 447.65], "HN": [230.8, 421.91], "HR": [521.64, 319.33], "HT": [272.8, 408.64], "HU": [531.38, 313.71], "ID": [795.7, 466.29], "IE": [453.57, 287.6], "IL": [573.01, 372.6], "IN": [697.02, 398.86], "IQ": [595.99, 365.4], "IR": [629.45, 367.67], "IS": [422.98, 223.19], "IT": [504.88, 321.94], "JM": [258.51, 412.1], "JO": [577.31, 373.33], "JP": [864.73, 355.28], "KE": [581.34, 462.13], "KG": [685.12, 335.05], "KH": [767.89, 427.93], "KP": [829.56, 341.26], "KR": [834.06, 355.35], "KW": [608.61, 377.29], "KZ": [670.62, 307.63], "LA": [762.96, 407.6], "LB": [576.7, 361.47], "LK": [701.73, 442.76], "LR": [446.62, 443.93], "LS": [554.59, 549.6], "LT": [543.3, 277.36], "LU": [491.94, 303.46], "LV": [549.36, 270.34], "LY": [532.02, 387.69], "MA": [456.12, 370.01], "MD": [554.55, 311.95], "ME": [529.13, 330.79], "MG": [606.1, 514.97], "MK": [535.51, 335.62], "ML": [470.0, 410.64], "MM": [744.51, 401.85], "MN": [768.71, 317.68], "MR": [447.99, 408.79], "MW": [569.68, 500.75], "MX": [189.64, 395.52], "MY": [794.38, 456.77], "MZ": [582.07, 502.64], "NA": [522.92, 521.56], "NC": [938.36, 523.24], "NE": [503.45, 413.85], "NG": [495.73, 436.78], "NI": [236.74, 428.04], "NL": [491.19, 290.34], "NO": [499.74, 246.65], "NP": [704.47, 378.13], "NZ": [949.71, 604.99], "OM": [636.33, 399.98], "PA": [248.28, 440.09], "PE": [270.9, 500.15], "PG": [876.89, 479.53], "PH": [815.63, 415.34], "PK": [663.23, 383.07], "PL": [530.2, 291.89], "PR": [287.59, 411.68], "PS": [574.19, 369.23], "PT": [451.81, 344.92], "PY": [306.61, 525.17], "QA": [618.76, 390.47], "RO": [545.22, 319.4], "RS": [533.53, 325.96], "RU": [757.99, 219.76], "RW": [560.07, 468.51], "SA": [600.9, 395.61], "SB": [922.09, 485.89], "SD": [557.77, 416.09], "SE": [530.07, 210.19], "SI": [516.95, 318.44], "SJ": [518.7, 89.46], "SK": [528.61, 307.03], "SL": [441.98, 439.79], "SN": [433.43, 420.5], "SO": [611.87, 436.67], "SR": [318.32, 451.67], "SS": [560.54, 443.47], "SV": [225.06, 424.29], "SY": [582.83, 358.77], "SZ": [563.19, 540.06], "TD": [529.51, 414.15], "TF": [669.76, 622.05], "TG": [478.19, 438.52], "TH": [759.23, 419.77], "TJ": [678.97, 347.4], "TL": [826.88, 488.34], "TM": [639.95, 342.5], "TN": [500.41, 363.18], "TR": [570.79, 343.56], "TT": [303.4, 434.09], "TW": [813.85, 396.1], "TZ": [570.78, 478.81], "UA": [565.79, 305.32], "UG": [567.72, 457.91], "US": [193.53, 340.36], "UY": [318.37, 560.62], "UZ": [654.03, 334.06], "VE": [295.19, 443.43], "VN": [770.43, 401.23], "VU": [943.28, 506.62], "XK": [533.86, 331.99], "YE": [601.37, 420.26], "ZA": [544.3, 550.6], "ZM": [548.78, 504.82], "ZW": [559.04, 516.84]};

window.WorldGameboard = function() {
  return {
    loaded: false,
    error: null,
    listView: false,
    currentFilter: "all",
    selectedCategory: "",
    categories: [],
    countriesData: {},
    challenges: [],
    targetingActive: false,
    liveFeedOpen: false,
    liveFeedEnabled: true,
    liveFeedMinimized: false,
    zoomAnimationEnabled: true,
    liveFeedEvents: [],
    liveFeedLoading: false,
    liveFeedInterval: null,
    liveFeedIntervalId: null,
    liveFeedIntervalTime: 45000,
    liveFeedBackoffMultiplier: 1.0,
    lastSolveId: 0,
    isFetchingFeed: false,
    lastFeedFetchTime: 0,
    gridTitle: "MATRIX COMMAND GRID",
    liveFeedTitle: "[ LIVE FEED ]",
    liveFeedSubtitle: "ORBITAL UPLINK ACTIVE • REAL-TIME FEED",
    liveFeedBtnLabel: "LIVE FEED",
    filterAllNodesEnabled: true,
    filterBreachedEnabled: true,
    filterHostileEnabled: true,
    filterCountsEnabled: true,
    sectorFilterEnabled: true,
    guideEnabled: true,
    viewToggleEnabled: true,

    // Target Finder (Quick Search) - Configurable via User Theme Settings
    searchQuery: "",
    searchResults: [],
    searchDropdownOpen: false,
    searchEnabled: false,

    // SVG Pan & Zoom State (ViewBox: 1008 x 651, Center: 504, 325.5)
    panX: 0,
    panY: 0,
    scale: 1.0,
    isDragging: false,
    lastMouseX: 0,
    lastMouseY: 0,

    async init() {
      // 1. Initialize live feed state from localStorage
      try {
        const savedFeed = localStorage.getItem("world_livefeed_open");
        if (savedFeed !== null) {
          this.liveFeedOpen = (savedFeed === "true");
        }
        const savedMinimized = localStorage.getItem("world_livefeed_minimized");
        if (savedMinimized !== null) {
          this.liveFeedMinimized = (savedMinimized === "true");
        }
      } catch(e) {}

      // 2. Load theme settings for title, default view, live feed, scanlines, glow, and zoom
      try {
        const getSettings = window.getWorldSettings || function() {
          return fetch("/api/v1/world/settings").then(r => r.json()).then(res => res.data || {}).catch(() => ({}));
        };
        const s = await getSettings();
        if (s) {
          if (s.grid_title) this.gridTitle = s.grid_title;
          if (s.default_view === "grid") this.listView = true;
          this.liveFeedEnabled = (s.live_feed_enabled !== false);
          this.liveFeedIntervalTime = Math.max(30, parseInt(s.live_feed_interval, 10) || 45) * 1000;
          this.zoomAnimationEnabled = (s.zoom_animation_enabled !== false);
          if (s.live_feed_title) this.liveFeedTitle = s.live_feed_title;
          if (s.live_feed_subtitle) this.liveFeedSubtitle = s.live_feed_subtitle;
          this.filterAllNodesEnabled = (s.filter_all_nodes_enabled !== false);
          this.filterBreachedEnabled = (s.filter_breached_enabled !== false);
          this.filterHostileEnabled = (s.filter_hostile_enabled !== false);
          this.filterCountsEnabled = (s.filter_counts_enabled !== false);
          this.sectorFilterEnabled = (s.sector_filter_enabled !== false);
          this.guideEnabled = (s.guide_enabled !== false);
          this.viewToggleEnabled = (s.view_toggle_enabled !== false);

          // User preferences from /settings or localStorage
          const userSearch = localStorage.getItem("world_user_search_enabled");
          this.searchEnabled = (userSearch !== null) ? (userSearch === "true") : false;

          const userCounts = localStorage.getItem("world_user_counts_enabled");
          if (userCounts !== null) {
            this.filterCountsEnabled = (userCounts === "true");
          }

          const userGuide = localStorage.getItem("world_user_guide_enabled");
          const tutorialCompleted = localStorage.getItem("world_theme_tutorial_completed_v1");
          if (userGuide !== null) {
            this.guideEnabled = (userGuide === "true");
          } else if (tutorialCompleted === "true") {
            this.guideEnabled = false;
          }

          window.addEventListener("world:guide-completed", () => {
            this.guideEnabled = false;
          });

          const wrapper = document.querySelector(".fb-gameboard-wrapper");
          if (wrapper) {
            if (s.scanlines_enabled) wrapper.classList.add("scanlines-active");
            else wrapper.classList.remove("scanlines-active");

            if (s.crt_glow_enabled !== false) wrapper.classList.add("crt-glow-active");
            else wrapper.classList.remove("crt-glow-active");
          }
        }
      } catch (e) {}

      // 3. Attach modal blur listener on #challenge-window to prevent aria-hidden focus warnings
      const chalModal = document.getElementById("challenge-window");
      if (chalModal) {
        chalModal.addEventListener("hide.bs.modal", () => {
          if (document.activeElement && chalModal.contains(document.activeElement)) {
            document.activeElement.blur();
          }
          chalModal.blur();
          if (document.body) {
            document.body.focus();
          }
        });
      }

      await this.loadMapData();
      this.initPanZoom();
      this.initKeyboardShortcuts();

      if (this.liveFeedEnabled) {
        this.fetchLiveFeed();
        this.startLiveFeedPolling();
      }

      // Page visibility listener: pause polling when tab is hidden, resume when visible
      document.addEventListener("visibilitychange", () => {
        if (!this.liveFeedEnabled) return;
        if (!document.hidden) {
          const now = Date.now();
          if (now - this.lastFeedFetchTime >= this.liveFeedIntervalTime) {
            this.liveFeedBackoffMultiplier = 1.0;
            this.fetchLiveFeed();
          }
          this.startLiveFeedPolling();
        } else {
          this.stopLiveFeedPolling();
        }
      });

      // Refresh map on challenge submission / reload
      window.addEventListener("load-challenges", async () => {
        await this.loadMapData();
        this.renderMapCountries();
        this.fetchLiveFeed();
      });

      // Reactive watch on sector filter for map view
      this.$watch("selectedCategory", () => {
        this.applyFilters();
      });

      // Handle deep link hash
      if (window.location.hash) {
        let chalHash = decodeURIComponent(window.location.hash.substring(1));
        let idx = chalHash.lastIndexOf("-");
        if (idx >= 0) {
          let id = chalHash.slice(idx + 1);
          if (id) {
            setTimeout(() => {
              this.loadChallenge(id);
            }, 600);
          }
        }
      }
    },

    async loadMapData() {
      this.error = null;
      try {
        let geoData = window._CTFD_WORLD_GEO || null;
        if (!geoData) {
          try {
            const cached = localStorage.getItem("ctfd_world_geo_cache");
            if (cached) geoData = JSON.parse(cached);
          } catch (e) {}
        }

        const fetchList = [
          fetch("/api/v1/world/countries"),
          fetch("/api/v1/challenges")
        ];
        if (!geoData) {
          fetchList.push(fetch("/api/v1/world/geo").then(r => r.json()).catch(() => null));
        }

        const results = await Promise.all(fetchList);
        const worldRes = results[0];
        const chalsRes = results[1];

        if (!geoData && results[2] && results[2].success) {
          geoData = results[2].data;
          window._CTFD_WORLD_GEO = geoData;
          try {
            localStorage.setItem("ctfd_world_geo_cache", JSON.stringify(geoData));
          } catch (e) {}
        }

        if (!worldRes.ok) {
          throw new Error(`HTTP error ${worldRes.status}: ${worldRes.statusText}`);
        }

        const worldJson = await worldRes.json();
        const chalsJson = chalsRes.ok ? await chalsRes.json() : { data: [] };

        if (worldJson.success && worldJson.data) {
          this.countriesData = worldJson.data;

          // If geoData was not loaded yet, attempt fallback fetch with geometry
          if (!geoData) {
            try {
              const fallbackRes = await fetch("/api/v1/world/countries?include_geometry=true");
              if (fallbackRes.ok) {
                const fallbackJson = await fallbackRes.json();
                if (fallbackJson.success && fallbackJson.data) {
                  geoData = {};
                  Object.keys(fallbackJson.data).forEach(iso => {
                    if (fallbackJson.data[iso] && fallbackJson.data[iso].d) {
                      geoData[iso] = {
                        d: fallbackJson.data[iso].d,
                        transform: fallbackJson.data[iso].transform || ""
                      };
                    }
                  });
                  window._CTFD_WORLD_GEO = geoData;
                  try {
                    localStorage.setItem("ctfd_world_geo_cache", JSON.stringify(geoData));
                  } catch(e) {}
                }
              }
            } catch(e) {}
          }

          // Merge cached SVG geometry
          if (geoData) {
            Object.keys(this.countriesData).forEach(iso => {
              if (geoData[iso]) {
                this.countriesData[iso].d = geoData[iso].d;
                this.countriesData[iso].transform = geoData[iso].transform;
              }
            });
          }

          // Map challenge IDs to country names, iso, and status
          const chalToCountry = {};
          const chalToIso = {};
          const chalToStatus = {};
          Object.values(this.countriesData).forEach(c => {
            if (c.challenge) {
              chalToCountry[c.challenge.id] = c.name;
              chalToIso[c.challenge.id] = c.iso;
              chalToStatus[c.challenge.id] = c.status;
            }
          });

          // Build list of all challenges from CTFd API
          let allChals = (chalsJson.data || []).map(c => ({
            ...c,
            country_name: chalToCountry[c.id] || "",
            country_iso: chalToIso[c.id] || "",
            status: chalToStatus[c.id] || (c.solved_by_me ? "captured_by_you" : "active")
          }));

          // If /api/v1/challenges didn't return any, fallback to countriesData challenges
          if (allChals.length === 0) {
            Object.values(this.countriesData).forEach(c => {
              if (c.challenge) {
                allChals.push({
                  ...c.challenge,
                  country_name: c.name,
                  country_iso: c.iso,
                  status: c.status
                });
              }
            });
          }

          const cats = new Set();
          allChals.forEach(c => {
            if (c.category) cats.add(c.category);
          });

          this.categories = Array.from(cats).sort();
          this.challenges = allChals;
          this.loaded = true;
          this.error = null;

          setTimeout(() => {
            this.renderMapCountries();
          }, 40);
        } else {
          this.loaded = true;
          this.error = "Telemetry link degraded: " + (worldJson.message || "Invalid response");
        }
      } catch (err) {
        console.error("[MatrixGrid] Failed to load world map data:", err);
        this.loaded = true;
        this.error = "Satellite uplink offline: " + (err.message || "Network error");
      }
    },

    renderMapCountries() {
      const container = document.getElementById("svg-countries-container");
      if (!container) return;
      container.innerHTML = "";

      const tooltip = document.getElementById("country-tooltip");
      const ttName = document.getElementById("tt-country-name");
      const ttChal = document.getElementById("tt-chal-name");
      const ttCat = document.getElementById("tt-chal-cat");
      const ttPts = document.getElementById("tt-chal-pts");
      const ttStatus = document.getElementById("tt-chal-status");

      Object.values(this.countriesData).forEach(c => {
        const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
        group.setAttribute("class", "country-group " + 
          (c.status !== "inactive" ? "active " : "") + 
          (c.status === "captured_by_you" ? "captured-you " : "") + 
          (c.status === "captured_by_opponent" ? "captured-opponent " : ""));
        group.setAttribute("data-iso", c.iso);

        // SVG Land Path (validate geometry string starts with M/m to prevent SVG path syntax error)
        let path = null;
        if (c.d && typeof c.d === "string" && (c.d.startsWith("M") || c.d.startsWith("m"))) {
          path = document.createElementNS("http://www.w3.org/2000/svg", "path");
          path.setAttribute("class", "land");
          path.setAttribute("d", c.d);
          group.appendChild(path);
        }
        container.appendChild(group);

        // Centroid Indicator Pin (ONLY for active/assigned territories!)
        if (c.status !== "inactive") {
          let cx = 0, cy = 0;
          if (typeof CALIBRATED_CENTROIDS !== "undefined" && CALIBRATED_CENTROIDS[c.iso]) {
            cx = CALIBRATED_CENTROIDS[c.iso][0];
            cy = CALIBRATED_CENTROIDS[c.iso][1];
          } else if (c.transform) {
            const m = c.transform.match(/translate\(\s*([-\d.]+)[,\s]+([-\d.]+)/);
            if (m) {
              cx = parseFloat(m[1]);
              cy = parseFloat(m[2]);
            }
          }

          // Fallback to path.getBBox() if neither calibrated override nor transform gave valid coordinates
          if (!cx && !cy && path) {
            try {
              const bbox = path.getBBox();
              if (bbox.width > 0 && bbox.height > 0) {
                cx = bbox.x + bbox.width / 2;
                cy = bbox.y + bbox.height / 2;
              }
            } catch(e) {}
          }

          c.centroid = { x: cx, y: cy };

          const pinG = document.createElementNS("http://www.w3.org/2000/svg", "g");
          pinG.setAttribute("transform", `translate(${cx}, ${cy})`);

          if (c.status === "captured_by_you") {
            // Breached by You: Precision Cyber Node Diamond with Sharp Technical Breached Marker
            pinG.setAttribute("class", "map-indicator indicator-solved");
            pinG.innerHTML = `
              <polygon points="0,-8 7,0 0,8 -7,0" fill="var(--matrix-green-subtle, rgba(0, 255, 102, 0.25))" stroke="var(--matrix-green-bright, #00ff66)" stroke-width="1.2"/>
              <circle cx="0" cy="0" r="3.2" fill="var(--matrix-green, #00ff66)"/>
              <path d="M-2,0 L-0.4,1.8 L2.4,-1.4" fill="none" stroke="var(--matrix-bg-dark, #020a04)" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/>
            `;
          } else if (c.status === "captured_by_opponent") {
            // Hostile / Breached by Opponent (Pulsing Crimson Radar Beacon + Target Triangle)
            pinG.setAttribute("class", "map-indicator indicator-hostile");
            pinG.innerHTML = `
              <circle cx="0" cy="0" r="6" fill="none" stroke="#ff1744" stroke-width="1.2" class="beacon-pulse-hostile"/>
              <polygon points="0,-7 5,3 -5,3" fill="#ff1744" stroke="#220005" stroke-width="0.6"/>
            `;
          } else {
            // Active / Uncompleted Challenge (Pulsing Radar Beacon + Target Triangle)
            pinG.setAttribute("class", "map-indicator indicator-active");
            pinG.innerHTML = `
              <circle cx="0" cy="0" r="6" fill="none" stroke="var(--matrix-green-bright)" stroke-width="1.2" class="beacon-pulse"/>
              <polygon points="0,-7 5,3 -5,3" fill="var(--matrix-green-bright)" stroke="var(--matrix-bg-dark, #04120a)" stroke-width="0.6"/>
            `;
          }
          group.appendChild(pinG);
        }

        // Hover & click events for active nodes
        if (c.status !== "inactive" && c.challenge) {
          const updateTooltipContent = () => {
            ttName.textContent = `${c.name} [${c.iso}]`;
            ttChal.textContent = c.challenge.name;
            ttCat.textContent = c.challenge.category || "EXPLOIT";
            ttPts.textContent = `${c.challenge.value} PTS`;

            if (c.status === "captured_by_you") {
              ttStatus.textContent = "[BREACHED - YOU]";
              ttStatus.style.color = "var(--matrix-green)";
              ttStatus.className = "mt-1 fw-bold font-monospace";
            } else if (c.status === "captured_by_opponent") {
              ttStatus.textContent = "[HOSTILE - OPPONENT]";
              ttStatus.style.color = "var(--matrix-crimson)";
              ttStatus.className = "mt-1 fw-bold font-monospace";
            } else {
              ttStatus.textContent = "[READY - CLICK TO ENGAGE]";
              ttStatus.style.color = "var(--matrix-green-bright)";
              ttStatus.className = "mt-1 fw-bold font-monospace";
            }
          };

          group.addEventListener("mouseenter", (e) => {
            if (this.targetingActive) return;
            updateTooltipContent();
          });

          group.addEventListener("mousemove", (e) => {
            if (this.targetingActive) return;
            updateTooltipContent();
            if (e.pageX && e.pageY) {
              tooltip.style.left = (e.pageX + 18) + "px";
              tooltip.style.top = (e.pageY + 18) + "px";
              tooltip.style.display = "block";
            }
          });

          group.addEventListener("mouseleave", () => {
            tooltip.style.display = "none";
            tooltip.style.top = "-9999px";
            tooltip.style.left = "-9999px";
          });

          group.addEventListener("click", () => {
            tooltip.style.display = "none";
            tooltip.style.top = "-9999px";
            tooltip.style.left = "-9999px";
            this.engageCountry(c);
          });
        }
      });

      this.applyFilters();
    },

    engageCountry(c) {
      if (!c.challenge) return;
      const tooltip = document.getElementById("country-tooltip");
      if (tooltip) {
        tooltip.style.display = "none";
        tooltip.style.top = "-9999px";
        tooltip.style.left = "-9999px";
      }

      this.targetingActive = true;
      if (window.WorldAudio) {
        window.WorldAudio.playBlip();
      }

      // Extract precision geometric centroid
      let targetX = (c.centroid && c.centroid.x) || (typeof CALIBRATED_CENTROIDS !== "undefined" && CALIBRATED_CENTROIDS[c.iso] ? CALIBRATED_CENTROIDS[c.iso][0] : 504);
      let targetY = (c.centroid && c.centroid.y) || (typeof CALIBRATED_CENTROIDS !== "undefined" && CALIBRATED_CENTROIDS[c.iso] ? CALIBRATED_CENTROIDS[c.iso][1] : 325.5);

      if (targetX === 504 && targetY === 325.5 && c.transform) {
        const match = c.transform.match(/translate\(\s*([-\d.]+)[,\s]+([-\d.]+)/);
        if (match) {
          targetX = parseFloat(match[1]);
          targetY = parseFloat(match[2]);
        }
      }

      // Activate SVG Tactical Sniper Reticle
      const reticle = document.getElementById("svg-sniper-reticle");
      if (reticle) {
        reticle.setAttribute("transform", `translate(${targetX}, ${targetY})`);
        reticle.style.display = "block";
        reticle.classList.remove("locking");
        void reticle.offsetWidth;
        reticle.classList.add("locking");
      }

      // If zoom animation is enabled, zoom camera directly onto the target
      if (this.zoomAnimationEnabled) {
        this.zoomTo(targetX, targetY, 2.6);
      }

      setTimeout(() => {
        this.targetingActive = false;
        if (reticle) reticle.style.display = "none";
        this.loadChallenge(c.challenge.id);
      }, 450);
    },

    zoomTo(targetX, targetY, newScale) {
      this.scale = newScale;
      // Places (targetX, targetY) at the dead center of the SVG viewBox (504, 325.5):
      this.panX = 504 - (targetX * newScale);
      this.panY = 325.5 - (targetY * newScale);
      this.clampPan();
      this.updateTransform(450);
    },

    clampPan() {
      if (this.scale <= 1.05) {
        this.panX = 0;
        this.panY = 0;
        this.scale = 1.0;
        return;
      }
      // Clamping bounds to ensure the map never flies off-screen
      const buffer = 40;
      const minPanX = 1008 * (1 - this.scale) - buffer;
      const maxPanX = buffer;
      const minPanY = 651 * (1 - this.scale) - buffer;
      const maxPanY = buffer;

      this.panX = Math.min(maxPanX, Math.max(minPanX, this.panX));
      this.panY = Math.min(maxPanY, Math.max(minPanY, this.panY));
    },

    initPanZoom() {
      const svg = document.getElementById("fb-gameboard-map");
      const g = document.getElementById("map-view-controller");
      if (!svg || !g) return;

      const getSvgPoint = (clientX, clientY) => {
        const pt = svg.createSVGPoint();
        pt.x = clientX;
        pt.y = clientY;
        const ctm = svg.getScreenCTM();
        if (ctm) {
          return pt.matrixTransform(ctm.inverse());
        }
        const rect = svg.getBoundingClientRect();
        return {
          x: (clientX - rect.left) * (1008 / rect.width),
          y: (clientY - rect.top) * (651 / rect.height)
        };
      };

      svg.addEventListener("mousedown", (e) => {
        if (e.button !== 0) return;
        this.isDragging = true;
        this.lastMouseX = e.clientX;
        this.lastMouseY = e.clientY;
      });

      window.addEventListener("mousemove", (e) => {
        if (!this.isDragging) return;
        const rect = svg.getBoundingClientRect();
        const svgScaleX = 1008 / rect.width;
        const svgScaleY = 651 / rect.height;
        const dx = (e.clientX - this.lastMouseX) * svgScaleX;
        const dy = (e.clientY - this.lastMouseY) * svgScaleY;
        this.lastMouseX = e.clientX;
        this.lastMouseY = e.clientY;

        this.panX += dx;
        this.panY += dy;
        this.clampPan();
        this.updateTransform();
      });

      window.addEventListener("mouseup", () => {
        this.isDragging = false;
      });

      svg.addEventListener("wheel", (e) => {
        e.preventDefault();
        const pt = getSvgPoint(e.clientX, e.clientY);
        const zoomFactor = e.deltaY < 0 ? 1.25 : 0.8;
        let newScale = this.scale * zoomFactor;

        if (newScale <= 1.05) {
          this.resetZoom();
          return;
        }

        newScale = Math.min(newScale, 7.0);

        // Zoom toward mouse pointer in SVG units
        this.panX = pt.x - (pt.x - this.panX) * (newScale / this.scale);
        this.panY = pt.y - (pt.y - this.panY) * (newScale / this.scale);
        this.scale = newScale;
        this.clampPan();
        this.updateTransform();
      }, { passive: false });
    },

    updateTransform(durationMs = 0) {
      const g = document.getElementById("map-view-controller");
      if (!g) return;
      if (durationMs > 0) {
        g.style.transition = `transform ${durationMs}ms cubic-bezier(0.16, 1, 0.3, 1)`;
        setTimeout(() => { g.style.transition = ""; }, durationMs);
      }
      g.setAttribute("transform", `translate(${this.panX}, ${this.panY}) scale(${this.scale})`);
    },

    zoomIn() {
      const newScale = Math.min(this.scale * 1.35, 7.0);
      this.panX = 504 - (504 - this.panX) * (newScale / this.scale);
      this.panY = 325.5 - (325.5 - this.panY) * (newScale / this.scale);
      this.scale = newScale;
      this.clampPan();
      this.updateTransform(200);
    },

    zoomOut() {
      const newScale = this.scale * 0.74;
      if (newScale <= 1.05) {
        this.resetZoom();
        return;
      }
      this.panX = 504 - (504 - this.panX) * (newScale / this.scale);
      this.panY = 325.5 - (325.5 - this.panY) * (newScale / this.scale);
      this.scale = newScale;
      this.clampPan();
      this.updateTransform(200);
    },

    resetZoom() {
      if (window.WorldAudio) {
        window.WorldAudio.playBlip();
      }
      this.scale = 1.0;
      this.panX = 0;
      this.panY = 0;
      this.updateTransform(300);
    },

    initKeyboardShortcuts() {
      window.addEventListener("keydown", (e) => {
        if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA") return;
        if (e.key === "+" || e.key === "=") {
          this.zoomIn();
        } else if (e.key === "-" || e.key === "_") {
          this.zoomOut();
        } else if (e.key === "0") {
          this.resetZoom();
        } else if (e.key === "/" && this.searchEnabled) {
          const searchInput = document.querySelector(".hud-search-input");
          if (searchInput && document.activeElement !== searchInput) {
            e.preventDefault();
            searchInput.focus();
            searchInput.select();
          }
        }
      });
    },

    setFilter(filter) {
      this.currentFilter = filter;
      this.applyFilters();
    },

    applyFilters() {
      const groups = document.querySelectorAll(".countries .country-group");
      groups.forEach(g => {
        const iso = g.getAttribute("data-iso");
        const c = this.countriesData[iso];
        if (!c) return;

        let visible = true;

        if (this.currentFilter === "mine" && c.status !== "captured_by_you") {
          visible = false;
        } else if (this.currentFilter === "others" && c.status !== "captured_by_opponent") {
          visible = false;
        }

        if (visible && this.selectedCategory) {
          if (!c.challenge || c.challenge.category !== this.selectedCategory) {
            visible = false;
          }
        }

        if (!visible) {
          g.style.opacity = "0.1";
          g.style.pointerEvents = "none";
        } else {
          g.style.opacity = "";
          g.style.pointerEvents = "";
        }
      });
    },

    toggleListView() {
      this.listView = !this.listView;
      if (!this.listView) {
        setTimeout(() => {
          this.renderMapCountries();
        }, 40);
      }
    },

    getActiveNodesCount() {
      if (!this.challenges) return 0;
      return this.challenges.filter(c => {
        if (this.selectedCategory && c.category !== this.selectedCategory) return false;
        return true;
      }).length;
    },

    getBreachedCount() {
      if (!this.challenges) return 0;
      return this.challenges.filter(c => {
        if (this.selectedCategory && c.category !== this.selectedCategory) return false;
        return !!c.solved_by_me;
      }).length;
    },

    getHostileCount() {
      if (!this.challenges) return 0;
      return this.challenges.filter(c => {
        if (this.selectedCategory && c.category !== this.selectedCategory) return false;
        return !c.solved_by_me && c.status === "captured_by_opponent";
      }).length;
    },

    filteredListChallenges() {
      return this.challenges.filter(c => {
        if (this.currentFilter === "mine" && !c.solved_by_me) return false;
        if (this.currentFilter === "others" && (c.solved_by_me || c.status !== "captured_by_opponent")) return false;
        if (this.selectedCategory && c.category !== this.selectedCategory) return false;
        if (this.searchQuery && this.searchQuery.trim()) {
          const q = this.searchQuery.toLowerCase().trim();
          const matchName = c.name && c.name.toLowerCase().includes(q);
          const matchCat = c.category && c.category.toLowerCase().includes(q);
          const matchCountry = c.country_name && c.country_name.toLowerCase().includes(q);
          const matchIso = c.country_iso && c.country_iso.toLowerCase().includes(q);
          if (!matchName && !matchCat && !matchCountry && !matchIso) return false;
        }
        return true;
      });
    },

    // Target Finder (Search Bar) Handlers
    onSearchInput() {
      const q = (this.searchQuery || "").trim().toLowerCase();
      if (!q) {
        this.searchResults = [];
        this.searchDropdownOpen = false;
        return;
      }
      const matches = this.challenges.filter(c => {
        const nameMatch = c.name && c.name.toLowerCase().includes(q);
        const catMatch = c.category && c.category.toLowerCase().includes(q);
        const countryMatch = c.country_name && c.country_name.toLowerCase().includes(q);
        const isoMatch = c.country_iso && c.country_iso.toLowerCase().includes(q);
        return nameMatch || catMatch || countryMatch || isoMatch;
      });
      this.searchResults = matches.slice(0, 8);
      this.searchDropdownOpen = (this.searchResults.length > 0 && !this.listView);
    },

    clearSearch() {
      this.searchQuery = "";
      this.searchResults = [];
      this.searchDropdownOpen = false;
    },

    selectSearchResult(chal) {
      this.searchDropdownOpen = false;
      if (this.listView) {
        this.loadChallenge(chal.id);
        return;
      }
      if (chal.country_iso && this.countriesData[chal.country_iso]) {
        this.engageCountry(this.countriesData[chal.country_iso]);
      } else {
        this.loadChallenge(chal.id);
      }
    },

    engageFirstSearchResult() {
      if (this.searchResults && this.searchResults.length > 0) {
        this.selectSearchResult(this.searchResults[0]);
      }
    },

    panToCountry(iso) {
      if (!iso) return;
      if (this.listView) {
        this.listView = false;
      }
      const countryObj = this.countriesData[iso];
      if (countryObj && countryObj.challenge) {
        this.engageCountry(countryObj);
        return;
      }
      let targetX = 504, targetY = 325.5;
      if (typeof CALIBRATED_CENTROIDS !== "undefined" && CALIBRATED_CENTROIDS[iso]) {
        targetX = CALIBRATED_CENTROIDS[iso][0];
        targetY = CALIBRATED_CENTROIDS[iso][1];
      }
      const reticle = document.getElementById("svg-sniper-reticle");
      if (reticle) {
        reticle.setAttribute("transform", `translate(${targetX}, ${targetY})`);
        reticle.style.display = "block";
        reticle.classList.remove("locking");
        void reticle.offsetWidth;
        reticle.classList.add("locking");
        setTimeout(() => { if (reticle) reticle.style.display = "none"; }, 1200);
      }
      this.zoomTo(targetX, targetY, 2.5);
    },

    loadChallenge(challengeId) {
      const id = parseInt(challengeId, 10);

      // Trigger CTFd native ChallengeBoard modal cleanly
      window.dispatchEvent(new CustomEvent("load-challenge", { detail: id }));
    },

    engageFromFeed(event) {
      if (!event || !event.challenge_id) return;
      if (event.country_iso && this.countriesData[event.country_iso]) {
        this.engageCountry(this.countriesData[event.country_iso]);
      } else {
        this.loadChallenge(event.challenge_id);
      }
    },

    toggleLiveFeed() {
      this.liveFeedOpen = !this.liveFeedOpen;
      try {
        localStorage.setItem("world_livefeed_open", this.liveFeedOpen ? "true" : "false");
      } catch(e) {}
      if (this.liveFeedOpen) {
        this.liveFeedBackoffMultiplier = 1.0;
        this.fetchLiveFeed(true);
      }
    },

    toggleMinimizeLiveFeed() {
      this.liveFeedMinimized = !this.liveFeedMinimized;
      try {
        localStorage.setItem("world_livefeed_minimized", this.liveFeedMinimized ? "true" : "false");
      } catch(e) {}
    },

    closeLiveFeed() {
      this.liveFeedOpen = false;
      try {
        localStorage.setItem("world_livefeed_open", "false");
      } catch(e) {}
    },

    startLiveFeedPolling() {
      this.stopLiveFeedPolling();
      if (!this.liveFeedEnabled) return;

      const schedule = () => {
        const backoff = Math.min(2.5, Math.max(1.0, this.liveFeedBackoffMultiplier || 1.0));
        const delay = Math.min(120000, Math.round(this.liveFeedIntervalTime * backoff));
        this.liveFeedIntervalId = setTimeout(async () => {
          if (document.hidden) {
            return; // tab hidden in background, don't poll
          }
          await this.fetchLiveFeed();
          schedule();
        }, delay);
        window._worldLiveFeedTimer = this.liveFeedIntervalId;
      };

      schedule();
    },

    stopLiveFeedPolling() {
      if (this.liveFeedIntervalId) {
        clearTimeout(this.liveFeedIntervalId);
        this.liveFeedIntervalId = null;
      }
      if (window._worldLiveFeedTimer) {
        clearTimeout(window._worldLiveFeedTimer);
        window._worldLiveFeedTimer = null;
      }
    },

    async fetchLiveFeed(force = false) {
      if (!this.liveFeedEnabled && !force) return;
      if (this.isFetchingFeed) return;

      // Throttle: avoid rapid repeat requests within 10s unless forced
      const now = Date.now();
      if (!force && this.lastFeedFetchTime && (now - this.lastFeedFetchTime < 10000)) {
        return;
      }

      this.isFetchingFeed = true;

      try {
        let url = "/api/v1/world/feed?limit=30";
        if (this.lastSolveId && this.liveFeedEvents && this.liveFeedEvents.length > 0) {
          url += `&since_id=${this.lastSolveId}`;
        }
        const res = await fetch(url, {
          headers: { "Accept": "application/json" }
        });

        this.lastFeedFetchTime = Date.now();

        if (res.status === 304) {
          // No changes since last poll - increase backoff slightly up to 2.5x
          this.liveFeedBackoffMultiplier = Math.min(2.5, (this.liveFeedBackoffMultiplier || 1.0) + 0.5);
          return;
        }

        if (res.status === 429) {
          // Rate limited: back off to maximum delay
          this.liveFeedBackoffMultiplier = 2.5;
          return;
        }

        if (res.ok) {
          const json = await res.json();
          if (json.success) {
            if (json.changed === false) {
              // Server confirms no new solves
              this.liveFeedBackoffMultiplier = Math.min(2.5, (this.liveFeedBackoffMultiplier || 1.0) + 0.5);
            } else if (Array.isArray(json.data) && json.data.length > 0) {
              this.liveFeedEvents = json.data;
              this.liveFeedBackoffMultiplier = 1.0; // Reset backoff on new events

              let maxId = json.last_id || 0;
              if (!maxId) {
                for (const ev of json.data) {
                  if (ev.solve_id && ev.solve_id > maxId) {
                    maxId = ev.solve_id;
                  }
                }
              }
              if (maxId) this.lastSolveId = maxId;
            }
          }
        }
      } catch (e) {
        // Silently ignore transient network drops or server restarts
      } finally {
        this.isFetchingFeed = false;
      }
    },

    formatFeedTime(dateStr) {
      if (!dateStr) return "";
      try {
        // CPQuest local fix: feed dates are UTC without an offset; parse them as UTC
        const d = new Date(/(Z|[+-]\d\d:?\d\d)$/i.test(dateStr) ? dateStr : dateStr + "Z");
        const now = new Date();
        const diffSec = Math.floor((now - d) / 1000);
        if (diffSec < 60) return "JUST NOW";
        if (diffSec < 3600) return `${Math.floor(diffSec / 60)}M AGO`;
        if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}H AGO`;
        return d.toISOString().slice(11, 19) + " UTC";
      } catch (e) {
        return dateStr;
      }
    },

    startTutorial() {
      if (window.startWorldTutorial) {
        window.startWorldTutorial(true);
      }
    }
  };
};

// Ensure registration and initialization across all module/script load orders
function setupAlpineBinding() {
  if (window.Alpine) {
    window.Alpine.data("WorldGameboard", window.WorldGameboard);
    const wrapper = document.querySelector(".fb-gameboard-wrapper");
    if (wrapper && (!wrapper._x_dataStack || wrapper._x_dataStack.length === 0)) {
      try {
        window.Alpine.initTree(wrapper);
      } catch (e) {
        console.warn("[MatrixGrid] Alpine initTree:", e);
      }
    }
  }
}

if (window.Alpine) {
  setupAlpineBinding();
} else {
  document.addEventListener("alpine:init", setupAlpineBinding);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", () => {
    setTimeout(setupAlpineBinding, 50);
  });
} else {
  setTimeout(setupAlpineBinding, 50);
}
